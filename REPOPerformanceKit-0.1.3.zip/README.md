# REPOPerformanceKit

A BepInEx plugin for R.E.P.O. that exposes a set of Unity engine configuration switches through a standard BepInEx config file. It does not patch any REPO game code.

The mod does not guarantee an FPS improvement. Whether it helps, hurts, or does nothing depends on your hardware, your other mods, and the specific scenes you play. Treat every feature as a knob you may or may not want to turn.

## What the DLL actually does

On plugin `Awake()`, it reads its config file and then:

- **Log filtering.** If `DisableUnityStackTraces = true`, calls `Application.SetStackTraceLogType(LogType.Log/Warning, StackTraceLogType.None)` and sets `Error/Exception/Assert` to `ScriptOnly`. If `SuppressPluginLogSpam` or `DedupeRepeatedLogs` is true, inserts a custom `BepInEx.Logging.ILogListener` in front of the existing listeners. The listener drops any Info/Debug/Message line whose text contains one of the configured substrings, and collapses consecutive identical lines to a `(previous message repeated N times)` summary. Warnings/Errors/Fatals are never filtered by substring.

- **Frame-rate related Unity values.** Sets `Time.maximumDeltaTime` to the configured value (default `0.1`). Optionally sets `QualitySettings.vSyncCount` (default: unchanged) and `Application.targetFrameRate` (default: unchanged).

- **GC tuning.** If `EnableIncrementalGC = true`, reflects into `UnityEngine.Scripting.GarbageCollector.GCMode` and sets it to `Enabled`. If that type or property isn't present, logs a warning and continues. If `CollectGCOnSceneLoad = true`, hooks `SceneManager.sceneLoaded` and calls `GC.Collect()` + `GC.WaitForPendingFinalizers()` on full (non-additive) scene loads.

- **Mipmap streaming.** If `EnableTextureStreaming = true`, sets `QualitySettings.streamingMipmapsActive = true`, `streamingMipmapsMemoryBudget` to the configured MB value (clamped to `[128, 8192]`, default `1024`), `streamingMipmapsMaxLevelReduction = 2`, `streamingMipmapsMaxFileIORequests = 256`, and `streamingMipmapsAddAllCameras = true`.

- **Adaptive fixedDeltaTime.** If `EnableAdaptivePhysics = true`, creates a `DontDestroyOnLoad` MonoBehaviour that samples smoothed unscaled FPS once per second. If smoothed FPS falls below `DegradeBelowFps` (default 40), sets `Time.fixedDeltaTime` to `DegradedFixedDeltaTime` (default 0.0333, i.e. 30 Hz). If it then rises above `RecoverAboveFps` (default 55), resets to `BaselineFixedDeltaTime` (default 0.02, i.e. 50 Hz).

- **Layer cull distances.** If `EnableCullDistanceBoost = true`, hooks `SceneManager.sceneLoaded` and sets `Camera.main.layerCullDistances` for layers `8..31` to `farClipPlane * Multiplier`, leaving layers `0..7` at the default. **The default `Multiplier` is `1.0`, which changes nothing.** Only becomes effective if you lower it in the config file.

- **Optional FPS overlay.** If `ShowFpsOverlay = true` (default `false`), creates a `DontDestroyOnLoad` MonoBehaviour that draws a single IMGUI label in the top-left corner showing smoothed FPS, frametime in ms, and the current physics tick rate derived from `Time.fixedDeltaTime`.

That is the complete list of things this plugin does. Everything is driven by `BepInEx/config/com.mentalize.repoperformance.cfg`; the file is auto-generated with defaults on first run.

## Install

Thunderstore Mod Manager: click Install. Manual: extract `REPOPerformance.dll` into `<profile>/BepInEx/plugins/REPOPerformanceKit/`. Requires `BepInEx-BepInExPack`.

## Compatibility

Client-side. No Harmony patches on REPO code, no network traffic, no lobby compatibility requirement. Each player can install independently.

Note that on a networked host, lowering `Time.fixedDeltaTime` via the adaptive physics feature affects the physics tick rate of objects the host simulates authoritatively over Photon. If you host and notice networked rigidbody behaviour feel imprecise during performance dips, set `EnableAdaptivePhysics = false`.

## Changelog

### 0.1.3
- Version bump (0.1.2 previously published).

### 0.1.2
- Rewrote description and README to strictly match the code's actual behaviour.

### 0.1.1
- Added `TextureStreaming` feature.

### 0.1.0
- Initial implementation (LogSuppressor, FrameRateTuner, GCTuner, AdaptivePhysics, CullDistanceBoost, FPSCounter).
